s1disasm_github madness
============

The very (worst) Sonic 1 Disassembly. 
edit everything you want there is no limit go crazy agian 

