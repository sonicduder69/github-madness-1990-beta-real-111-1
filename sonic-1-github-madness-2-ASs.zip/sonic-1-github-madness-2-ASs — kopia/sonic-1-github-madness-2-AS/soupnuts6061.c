#include <sonicgithubmadness.h>
#include "discord.h"
#include "life.h"

for(;;){
  discord.postMessage(random.str());
}
